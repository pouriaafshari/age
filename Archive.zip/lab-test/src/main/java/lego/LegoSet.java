package lego;

import java.util.Comparator;
import java.util.Objects;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LegoSet implements Comparable<LegoSet>{
    public static final LegoCompar LC = new LegoCompar();

    @EqualsAndHashCode.Include
    private String code;
    private String name;
    private int bricks;
    private Theme theme;
    @ToString.Exclude
    private Set<Minifigures> minifigures;
    @Override
    public int compareTo(LegoSet o) {
        return Objects.compare(this, o, LC);
    }

    public enum Theme {
        @JsonProperty("City") CITY,
        @JsonProperty("Star Wars") STAR_WARS,
        @JsonProperty("Harry Potter") HARRY_POTTER,
        @JsonProperty("Creator Expert") CREATOR_EXPERT;
    }
    @NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
    @AllArgsConstructor
    @Getter(AccessLevel.PUBLIC)
    @ToString
    @EqualsAndHashCode(onlyExplicitlyIncluded = true)
    public static class Minifigures {
        @EqualsAndHashCode.Include
        private final String id;
        private final String name;
        private final int quantity;
    }

    public static class LegoCompar implements Comparator<LegoSet> {

        @Override
        public int compare(LegoSet o1, LegoSet o2) {
            if (o1.bricks != o2.bricks) {
                return Objects.compare(o1.bricks, o2.bricks, Comparator.reverseOrder());
            }
            return Objects.compare(o1.code, o2.code, Comparator.naturalOrder());
        }
    }
}
