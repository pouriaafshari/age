package lego;

import lombok.NonNull;

import java.io.IOException;
import java.util.*;

public class LegoRepo extends base.Repository<LegoSet> implements base.Queries<LegoSet, LegoSet.Minifigures, LegoSet.Theme>{

    /**
     * A constructor for initializing the repository.
     *
     * @throws IOException if an I/O error happens
     */
    protected LegoRepo() throws IOException {
        super(LegoSet.class);
    }

    @Override
    public int getMaximumOfPieces() {
        int MAX = getAll().get(0).getBricks();
        for (int i=0; i<getAll().size(); i++) {
            if (getAll().get(i).getBricks() > MAX) {
                MAX = getAll().get(i).getBricks();
            }
        }
        return MAX;
    }

    @Override
    public List<LegoSet> getSetsOrderByCountOfBricksDescThenByNumber() {
        List<LegoSet> LS = new ArrayList<>(getAll());
        LS.sort(LegoSet.LC);
        return LS;
    }

    @Override
    public Set<String> getNamesOfSetsByTheme(LegoSet.@NonNull Theme theme) {
        Set<String> SS = new HashSet<>();
        for (int i=0; i<getAll().size(); i++) {
            if (getAll().get(i).getTheme()==theme) SS.add(getAll().get(i).getName());
        }
        return SS;
    }

    @Override
    public Map<String, LegoSet.Theme> getThemesByCodes() {
        Map<String, LegoSet.Theme> MSL = new HashMap<>();
        for (int i=0; i<getAll().size(); i++) {
            MSL.put(getAll().get(i).getCode(), getAll().get(i).getTheme());
        }
        return MSL;
    }

    @Override
    public Map<Integer, Set<LegoSet>> getSetsByPieces() {
        Map<Integer, Set<LegoSet>> MIS = new HashMap<>();
        for (LegoSet LS : getAll()) {
            MIS.putIfAbsent(LS.getBricks(), new HashSet<>());
            MIS.get(LS.getBricks()).add(LS);
        }
        return MIS;
    }

    public static void main(String[] args) throws IOException {
        LegoRepo LR = new LegoRepo();

        System.out.println(LR.getMaximumOfPieces());
        System.out.println(LR.getSetsByPieces());
        System.out.println(LR.getThemesByCodes());
        System.out.println(LR.getNamesOfSetsByTheme(LegoSet.Theme.CITY));
        System.out.println(LR.getSetsOrderByCountOfBricksDescThenByNumber());
    }
}
