package base;

import lombok.NonNull;

import java.util.List;
import java.util.Set;

/**
 * Defines queries for your {@link Repository} implementation.
 *
 * @param <T> the type of your entity (first class)
 * @param <U> the type of your nested class (second class)
 * @param <V> the type of your enum class
 */
public interface Queries<T, U, V extends Enum<V>> {
    /**
     * Returns the minimum number of configurations.
     *
     * @return the minimum value
     */
    int getMinimumNumberOfConfigurations();

    /**
     * Returns the list of aircraft types ordered by:
     *
     * <ol>
     *     <li>the number (descending)
     *     <li>the number of configurations (ascending)
     * </ol>
     *
     * <strong>The method cannot modify the original list.</strong>
     *
     * @return the sorted list
     */
    List<T> getAircraftTypesOrderByNumberDescThenByNumberOfConfigurationsAsc();

    /**
     * Returns each type number that is built by the given manufacturer.
     *
     * @param manufacturer the theme
     * @return the numbers
     */
    Set<String> getNumbersByManufacturer(
            @NonNull V manufacturer);

    /**
     * Returns each configuration which has more economy seats than {@code economyLimit} or more business seats than {@code businessLimit}.
     *
     * @param economyLimit  limit for the economy seats
     * @param businessLimit limit for the business seats
     * @return the set of configurations
     */
    Set<U> getConfigurationsBySeats(
            int economyLimit,
            int businessLimit);
}