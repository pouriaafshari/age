package aviation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Comparator;
import java.util.Objects;
import java.util.Set;

@NoArgsConstructor(access = AccessLevel.PACKAGE)
@AllArgsConstructor
@Getter
@Setter(AccessLevel.PROTECTED)
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Aircraft implements Comparable<Aircraft>{

    public static final COMPAR COMPARATOR = new COMPAR();

    @ToString.Include
    @EqualsAndHashCode.Include
    private String number;
    private int year;
    @ToString.Include
    private Manufacturer manufacturer;
    private Set<Configurations> configurations;

    @Override
    public int compareTo(Aircraft o) {
        return Objects.compare(this,o,COMPARATOR);
    }


    @NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
    @AllArgsConstructor
    @Getter
    @ToString
    @EqualsAndHashCode(onlyExplicitlyIncluded = true)
    public static class Configurations{
        @EqualsAndHashCode.Include
        private final String code;
        private final int economy;
        private final int business;

    }

    public enum Manufacturer{
        @JsonProperty("Airbus") AIRBUS,
        @JsonProperty("Boeing") BOEING,
        @JsonProperty("Embraer") EMBRAER,
        @JsonProperty("Bombardier") BOMBARDIER
    }
    public static class COMPAR implements Comparator<Aircraft>{

        @Override
        public int compare(Aircraft o1, Aircraft o2) {
            if (Objects.equals(o1.number, o2.number)){
                return Objects.compare(o1.getNumber(), o2.getNumber(), Comparator.naturalOrder());
            }
            return Objects.compare(o1.year, o2.year, Comparator.reverseOrder());
        }
    }


}