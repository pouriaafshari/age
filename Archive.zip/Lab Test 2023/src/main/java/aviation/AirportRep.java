package aviation;

import base.Queries;
import base.Repository;
import lombok.NonNull;

import java.io.IOException;
import java.util.*;

public class AirportRep extends Repository<Aircraft> implements Queries<Aircraft, Aircraft.Configurations, Aircraft.Manufacturer> {

    /**
     * A constructor for initializing the repository.
     *
     * @throws IOException if an I/O error happens
     */
    protected AirportRep() throws IOException {
        super(Aircraft.class);
    }

    @Override
    public int getMinimumNumberOfConfigurations() {
        int MIN = getAll().get(0).getConfigurations().size();
        for (int i=1; i<getAll().size(); i++) {
            if (getAll().get(i).getConfigurations().size() < MIN) {
                MIN = getAll().get(i).getConfigurations().size();
            }
        }
        return MIN;
    }

    @Override
    public List<Aircraft> getAircraftTypesOrderByNumberDescThenByNumberOfConfigurationsAsc() {
        List<Aircraft> result = new ArrayList<>(getAll());
        class Sex implements Comparator<Aircraft>{

            @Override
            public int compare(Aircraft o1, Aircraft o2) {
                if (!o1.getNumber().equals(o2.getNumber())){
                    return -o1.getNumber().compareTo(o2.getNumber());
                }
                return Integer.compare(o1.getConfigurations().size(),o2.getConfigurations().size());
            }
        }
        Sex SS = new Sex();
        result.sort(SS);
        return result;
    }

    @Override
    public Set<String> getNumbersByManufacturer(Aircraft.@NonNull Manufacturer manufacturer) {
        Set<String> result = new HashSet<>();

        for (Aircraft aircraft: getAll()){
            if (aircraft.getManufacturer() == manufacturer){
                result.add(aircraft.getNumber());
            }
        }
        return result;
    }

    @Override
    public Set<Aircraft.Configurations> getConfigurationsBySeats(int economyLimit, int businessLimit) {
        Set<Aircraft.Configurations> SAC = new HashSet<>();
        for (Aircraft AI : getAll()) {
            for (Aircraft.Configurations MM : AI.getConfigurations()) {
                if (MM.getEconomy() > economyLimit || MM.getBusiness() > businessLimit) {
                    SAC.add(MM);
                }
            }
        }
        return SAC;
    }

    public static void main(String[] args) throws IOException {
        AirportRep airportRep = new AirportRep();
        System.out.println(airportRep.getMinimumNumberOfConfigurations());
        System.out.println(airportRep.getNumbersByManufacturer(Aircraft.Manufacturer.AIRBUS));
        System.out.println(airportRep.getAircraftTypesOrderByNumberDescThenByNumberOfConfigurationsAsc());
        System.out.println(airportRep.getConfigurationsBySeats(250, 5));
    }
}